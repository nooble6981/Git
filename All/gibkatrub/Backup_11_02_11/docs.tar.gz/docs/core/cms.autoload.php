<?php
/**
 * Eresus CMS 2.15
 *
 * Система управления контентом Eresus
 *
 * Таблица автозагрузки классов
 *
 * @copyright 2009, Eresus Project, http://eresus.ru/
 * @license http://www.gnu.org/licenses/gpl.txt GPL License 3
 * @author Mikhail Krasilnikov <mk@procreat.ru>
 *
 * Данная программа является свободным программным обеспечением. Вы
 * вправе распространять ее и/или модифицировать в соответствии с
 * условиями версии 3 либо (по вашему выбору) с условиями более поздней
 * версии Стандартной Общественной Лицензии GNU, опубликованной Free
 * Software Foundation.
 *
 * Мы распространяем эту программу в надежде на то, что она будет вам
 * полезной, однако НЕ ПРЕДОСТАВЛЯЕМ НА НЕЕ НИКАКИХ ГАРАНТИЙ, в том
 * числе ГАРАНТИИ ТОВАРНОГО СОСТОЯНИЯ ПРИ ПРОДАЖЕ и ПРИГОДНОСТИ ДЛЯ
 * ИСПОЛЬЗОВАНИЯ В КОНКРЕТНЫХ ЦЕЛЯХ. Для получения более подробной
 * информации ознакомьтесь со Стандартной Общественной Лицензией GNU.
 *
 * Вы должны были получить копию Стандартной Общественной Лицензии
 * GNU с этой программой. Если Вы ее не получили, смотрите документ на
 * <http://www.gnu.org/licenses/>
 *
 * @package Eresus2
 *
 * $Id: cms.autoload.php 1308 2010-12-29 16:59:38Z mk $
 */

return array(
	'AdminFileManager' => 'admin/components/FileManager/AdminFileManager.php',
	'EresusForm' => 'core/EresusForm.php',
	'I18n' => 'core/i18n.php',
	'PaginationHelper' => 'core/classes/helpers/PaginationHelper.php',
	'WebServer' => 'core/classes/WebServer.php',
	'WebPage' => 'core/classes/WebPage.php',
);
