﻿// I18N constants
//
//LANG: "base", ENCODING: UTF-8
//Author: Mikhail Krasilnokov, <mk@procreat.ru>
// FOR TRANSLATORS:
//
//   1. PLEASE PUT YOUR CONTACT INFO IN THE ABOVE LINE
//      (at least a valid email address)
//
//   2. PLEASE TRY TO USE UTF-8 FOR ENCODING;
//      (if this is not possible, please include a comment
//       that states what encoding is necessary.)

{
  "Anchor name": "Имя якоря",
  "Cancel": "Отмена",
  "Delete": "Удалить",
  "Insert Anchor": "Вставить якорь",
  "OK": "OK"
}
