﻿// I18N constants
// LANG: "ru", ENCODING: UTF-8
// Author: Mikhail Krasilnikov, <mk@procreat.ru>
{
  "Default": "Обычный",
  "Undefined": "Без стилей",
  "Choose stylesheet": "Выберите класс CSS для элемента"
};