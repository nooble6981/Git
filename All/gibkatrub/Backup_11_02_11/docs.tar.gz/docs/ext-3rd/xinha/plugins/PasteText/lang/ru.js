﻿// I18N constants
// LANG: "ru", ENCODING: UTF-8
{
  "Paste as Plain Text": "Вставить как текст (без форматирования)"
};