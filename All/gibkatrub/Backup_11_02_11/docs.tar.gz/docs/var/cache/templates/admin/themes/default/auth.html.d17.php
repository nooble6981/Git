<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="ru" xml:lang="ru">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1251" />
	<title>Вход - Eresus CMS</title>
	<link rel="StyleSheet" type="text/css" href="<?php echo $this->scope["siteRoot"];?>/admin/themes/default/theme.css" />
	<link rel="StyleSheet" type="text/css" href="<?php echo $this->scope["siteRoot"];?>/admin/themes/default/auth.css" />
</head>
<body onload="document.getElementById('user').focus();">

	<table id="body">
		<tr>
			<td>

				<div id="auth-dialog">
					<form id="auth-form" action="<?php echo $this->scope["siteRoot"];?>/admin.php" method="post">

						<div class="title">���� � ������ ����������</div>
						<div class="content">
							<div class="label"><label for="user">������������:</label></div>
							<div><input type="text" name="user" id="user"<?php if ((isset($this->scope["user"]) ? $this->scope["user"] : null)) {
?> value="<?php echo $this->scope["user"];?>"<?php 
}?> /></div>
							<div class="label"><label for="password">������:</label></div>
							<div><input type="password" name="password" id="password" /></div>
							<div class="checkbox">
								<label for="autologin">
									<input type="checkbox" name="autologin" id="autologin" value="1"<?php if ((isset($this->scope["autologin"]) ? $this->scope["autologin"] : null)) {
?> checked="checked"<?php 
}?> />
									���������
								</label>
							</div>
						</div>
						<div class="buttons">
							<button type="submit">�����</button>
						</div>
					</form>
				</div>

			</td>
		</tr>
	</table>

</body>
</html><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>