<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><a href="<?php echo $this->scope["listURL"];?>">&laquo; ��������� � ������</a>
	<div class="tovars">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td style="width:210px"><?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'thumbURL',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true)) {
?><img src="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'thumbURL',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?>" alt="" /><?php 
}
else {
?>��� ����<?php 
}?></td>
          <td>
          <div>
            <h3><a href="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'clientURL',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?>" class="green"><?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?></a></h3>
            <p><strong>�������:</strong> <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'article',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?></p>
            <p><strong>��������:</strong> <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?></p>
            <p><strong>����:</strong> <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'cost',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?> ���.</p>
            <p><strong>��������:</strong> <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'description',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?></p>
            <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',    1 => '.',  ),  2 =>   array (    0 => 'settings',    1 => 'brandsEnabled',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',  ),), (isset($this->scope["this"]) ? $this->scope["this"]:null), true) && $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'brand',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true)) {
?>
	          <P><strong>�����</strong>:<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',    1 => '->',  ),  2 =>   array (    0 => 'brand',    1 => 'title',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',  ),), $this->scope["good"], false);?> <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',    1 => '->',  ),  2 =>   array (    0 => 'brand',    1 => 'logoURL',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true)) {
?><img src="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',    1 => '->',  ),  2 =>   array (    0 => 'brand',    1 => 'logoURL',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',  ),), $this->scope["good"], false);?>" alt="" /><?php 
}
else {
?>��� ��������<?php 
}?></p>
            <?php 
}?>


            </div>
          </td>
        </tr>
      </table>
     <p><strong>����������:</strong></p>
    <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'photoURL',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true)) {
?><img src="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'photoURL',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?>" alt="" /><?php 
}
else {
?>��� ����������<?php 
}?>

    <div class="clear"></div>
      
<?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',    1 => '.',  ),  2 =>   array (    0 => 'settings',    1 => 'extPhotosEnabled',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',  ),), (isset($this->scope["this"]) ? $this->scope["this"]:null), true)) {
?>
<p> </p>
<?php 
$_fh0_data = $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'photos',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true);
if ($this->isArray($_fh0_data) === true)
{
	foreach ($_fh0_data as $this->scope['photo'])
	{
/* -- foreach start output */
?>
<a href="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'clientPopup',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["photo"], false);?>"><img src="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'thumbURL',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["photo"], false);?>" /></a>
<?php 
/* -- foreach end output */
	}
}?>

<?php 
}?>

 </div>
<div class="clear"></div><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>