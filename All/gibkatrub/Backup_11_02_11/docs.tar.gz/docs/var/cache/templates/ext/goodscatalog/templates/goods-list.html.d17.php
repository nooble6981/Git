<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><div class="ui-button-box">
	<a href="admin.php?mod=content&section=<?php echo $this->scope["section"];?>&action=add" class="ui-button ui-button-list-add">�������� �����</a>
</div>

<?php if (count((isset($this->scope["goods"]) ? $this->scope["goods"] : null)) > 0) {
?>
<table class="goods-list ui-widget ui-widget-content">
	<tr>
		<th>&nbsp;</th>
		<th>�������</th>
		<th>��������</th>
		<?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',    1 => '.',  ),  2 =>   array (    0 => 'settings',    1 => 'mainPhotoEnabled',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',  ),), (isset($this->scope["this"]) ? $this->scope["this"]:null), true)) {
?><th>�������� ����</th><?php 
}?>

		<th>����</th>
		<?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',    1 => '.',  ),  2 =>   array (    0 => 'settings',    1 => 'specialsEnabled',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',  ),), (isset($this->scope["this"]) ? $this->scope["this"]:null), true)) {
?><th>����.</th><?php 
}?>

	</tr>
	<?php 
$_fh0_data = (isset($this->scope["goods"]) ? $this->scope["goods"] : null);
if ($this->isArray($_fh0_data) === true)
{
	foreach ($_fh0_data as $this->scope['good'])
	{
/* -- foreach start output */
?>
	<tr class="goods-list-item">
		<td class="controls">
			<a href="<?php echo sprintf((isset($this->scope["urlEdit"]) ? $this->scope["urlEdit"] : null), $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true));?>" title="��������"><img src="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'root',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["Eresus"], false);
echo $this->scope["theme"]->getIcon('item-edit.png');?>" alt="[��������]" /></a>
			<a href="<?php echo sprintf((isset($this->scope["urlToggle"]) ? $this->scope["urlToggle"] : null), $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true));?>" title="<?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'active',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true)) {
?>���������<?php 
}
else {
?>��������<?php 
}?>"><img src="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'root',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["Eresus"], false);
if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'active',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true)) {

echo $this->scope["theme"]->getIcon('item-active.png');

}
else {

echo $this->scope["theme"]->getIcon('item-inactive.png');

}?>"	alt="[<?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'active',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true)) {
?>���������<?php 
}
else {
?>��������<?php 
}?>]" /></a>
			<a href="<?php echo sprintf((isset($this->scope["urlUp"]) ? $this->scope["urlUp"] : null), $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true));?>" title="�������"><img src="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'root',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["Eresus"], false);
echo $this->scope["theme"]->getIcon('move-up.png');?>" alt="[�������]" /></a>
			<a href="<?php echo sprintf((isset($this->scope["urlDown"]) ? $this->scope["urlDown"] : null), $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true));?>" title="��������"><img src="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'root',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["Eresus"], false);
echo $this->scope["theme"]->getIcon('move-down.png');?>" alt="[��������]" /></a>
			&nbsp;
			<a href="<?php echo sprintf((isset($this->scope["urlDelete"]) ? $this->scope["urlDelete"] : null), $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true));?>" title="�������" class="delete"><img src="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'root',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["Eresus"], false);
echo $this->scope["theme"]->getIcon('item-delete.png');?>" alt="[�������]" /></a>
		</td>
		<td class="article"><?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'article',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?></td>
		<td class="title"><?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?></td>
		<?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',    1 => '.',  ),  2 =>   array (    0 => 'settings',    1 => 'mainPhotoEnabled',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',  ),), (isset($this->scope["this"]) ? $this->scope["this"]:null), true)) {
?><td class="photo"><?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'thumbURL',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true)) {
?><img src="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'thumbURL',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?>" alt="�������� ����" /><?php 
}?></td><?php 
}?>

		<td class="cost"><?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'cost',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?></td>
		<?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',    1 => '.',  ),  2 =>   array (    0 => 'settings',    1 => 'specialsEnabled',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',  ),), (isset($this->scope["this"]) ? $this->scope["this"]:null), true)) {
?><td class="special"><?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'special',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true)) {
?>��<?php 
}?></td><?php 
}?>

	</tr>
	<?php 
/* -- foreach end output */
	}
}?>

</table>
<?php if ((isset($this->scope["pagination"]) ? $this->scope["pagination"] : null)) {
?>
<?php echo $this->scope["pagination"]->render();?>

<?php 
}?>

<?php 
}
else {
?>
<div class="ui-widget">
	<div class="ui-widget-content ui-padding ui-helper-padding">
		� ���� ������� ���� ��� �������.
	</div>
</div>
<?php 
}
 /* end template body */
return $this->buffer . ob_get_clean();
?>