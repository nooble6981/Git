<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><div class="box ui-widget-content" style="min-width: 600px; float: left;">
	<div class="header">���������� ����������</div>
	<div class="content">

		<form action="admin.php" method="post" enctype="multipart/form-data" id="catalogPhotoAddDialog">

			<div class="hidden">
				<input type="hidden" name="mod" value="content" />
				<input type="hidden" name="section" value="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'section',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?>" />
				<input type="hidden" name="id" value="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?>" />
				<input type="hidden" name="action" value="photo_insert" />
			</div>

			<label for="catalog-file1-input">�� ������ ������� �� 5-�� ������:</label>
			<ol>
				<li><input type="file" name="file1" id="catalog-file1-input" /></li>
				<li class="hidden"><input type="file" name="file2" /></li>
				<li class="hidden"><input type="file" name="file3" /></li>
				<li class="hidden"><input type="file" name="file4" /></li>
				<li class="hidden"><input type="file" name="file5" /></li>
			</ol>
			<div class="ui-minor">������ JPEG, PNG ��� GIF. ������ ����� �� ����� <?php echo ini_get('upload_max_filesize');?></div>
			
			<div class="ui-button-box">
				<br />
				<button type="submit">��������</button>
				<button type="button" class="cancel" onclick="history.back();">��������</button>
			</div>
			
		</form>
	</div>
</div>
<script type="text/javascript"><!--//--><![CDATA[//><!--
jQuery(document).ready(function () 
{
	jQuery("#catalogPhotoAddDialog input:file").live('change', function ()
	{
		jQuery(this).parent().next().show().children('input').focus();
	});
});
//--><!]]></script>
<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>