<?php
/* template head */
if (function_exists('Dwoo_Plugin_escape')===false)
	$this->getLoader()->loadPlugin('escape');
/* end template head */ ob_start(); /* template body */ ?><form xmlns:fc="http://eresus.ru/schema/form/" action="admin.php" enctype="multipart/form-data" id="settingsForm" class="ui-widget ui-widget-content ui-corner-all">

	<div class="hidden">
		<input type="hidden" name="mod" value="content" />
		<input type="hidden" name="update" value="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?>" />
	</div>

	<fc:tabwidget id="catalogEdit">

		<fc:tabcontrol>
			<fc:tab name="main">�������� ������</fc:tab>
			<?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',    1 => '.',  ),  2 =>   array (    0 => 'settings',    1 => 'extPhotosEnabled',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',  ),), (isset($this->scope["this"]) ? $this->scope["this"]:null), true)) {
?>
			<fc:tab name="images">�������������� ����������</fc:tab>
			<?php 
}?>

	</fc:tabcontrol>
	

		<fc:tabs>

			<fc:tab name="main">
				<table width="100%">
					<colgroup>
						<col width="10%" />
						<col width="*" />
					</colgroup>
					<tr>
						<td class="formLabel">
							<label for="catalog-article-input">�������</label>
						</td>
						<td>
							<input type="text" name="article" id="catalog-article-input" value="<?php echo Dwoo_Plugin_escape($this, $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'article',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true), 'html', null);?>" maxlength="255" />
						</td>
					</tr>
					<tr>
						<td class="formLabel">
							<label for="catalog-title-input">��������</label>
						</td>
						<td>
							<input type="text" name="title" id="catalog-title-input" value="<?php echo Dwoo_Plugin_escape($this, $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true), 'html', null);?>" maxlength="255" class="full-width" />
						</td>
					</tr>
					<tr>
						<td colspan="2">
							<label for="catalog-about-input">������� ��������</label><br />
							<textarea name="about" id="catalog-about-input" cols="40" rows="5" class="full-width"><?php echo Dwoo_Plugin_escape($this, $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'about',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true), 'html', null);?></textarea>
						</td>
					</tr>
					<tr>
						<td colspan="2">
							<label for="wyswyg_description">��������</label><br />
							<textarea name="wyswyg_description" id="wyswyg_description" cols="40" rows="8" class="tinymce_default wysiwyg full-width"><?php echo Dwoo_Plugin_escape($this, $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'description',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true), 'html', null);?></textarea>
						</td>
					</tr>
					<tr>
						<td class="formLabel">
							<label for="catalog-cost-input">����</label>
						</td>
						<td>
							<input type="text" name="cost" id="catalog-cost-input" value="<?php echo Dwoo_Plugin_escape($this, $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'cost',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true), 'html', null);?>"  maxlength="20" size="5" class="number" />
						</td>
					</tr>
					<?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',    1 => '.',  ),  2 =>   array (    0 => 'settings',    1 => 'mainPhotoEnabled',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',  ),), (isset($this->scope["this"]) ? $this->scope["this"]:null), true)) {
?>
					<tr>
						<td></td><td><?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'thumbURL',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true)) {
?><a href="#" onclick="return false;" class="pseudo good-photo-preview">�������� �������� ����<img src="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'thumbURL',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?>" alt="" /></a><?php 
}?></td>
					</tr>
					<tr>
						<td class="formLabel">
							<label for="catalog-photo-input">�������� ����������</label>
						</td>
						<td>
							<input type="file" name="photo" id="catalog-photo-input" />
							<div class="ui-minor">������ JPEG, PNG ��� GIF. ������ ����� �� ����� <?php echo ini_get('upload_max_filesize');?></div>
						</td>
					</tr>
					<?php 
}?>

					<tr>
						<td></td>
						<td>
							<label for="catalog-active-input">
								<input type="checkbox" name="active" value="1" id="catalog-active-input"<?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'active',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true)) {
?> checked="checked"<?php 
}?> />
								���������� ����� �����������
							</label>
						</td>
					</tr>
					<?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',    1 => '.',  ),  2 =>   array (    0 => 'settings',    1 => 'specialsEnabled',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',  ),), (isset($this->scope["this"]) ? $this->scope["this"]:null), true)) {
?>
					<tr>
						<td></td>
						<td>
							<label for="catalog-special-input">
								<input type="checkbox" name="special" value="1" id="catalog-special-input"<?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'special',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true)) {
?> checked="checked"<?php 
}?> />
								���� ����� ���������������
							</label>
						</td>
					</tr>
					<?php 
}?>

					<?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',    1 => '.',  ),  2 =>   array (    0 => 'settings',    1 => 'brandsEnabled',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',  ),), (isset($this->scope["this"]) ? $this->scope["this"]:null), true)) {
?>
					<tr>
						<td class="formLabel">
							<label for="catalog-brand-input">�����</label>
						</td>
						<td>
							<select name="brand" id="catalog-brand-input">
								<option value="">(�� ��������� �� � ������ ������)</option>
								<?php 
$_fh0_data = (isset($this->scope["brands"]) ? $this->scope["brands"] : null);
if ($this->isArray($_fh0_data) === true)
{
	foreach ($_fh0_data as $this->scope['brand'])
	{
/* -- foreach start output */
?>
								<option value="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["brand"], false);?>"<?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',    1 => '->',  ),  2 =>   array (    0 => 'brand',    1 => 'id',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true) == $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["brand"]) ? $this->scope["brand"]:null), true)) {
?> selected="selected"<?php 
}?>><?php echo Dwoo_Plugin_escape($this, $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["brand"]) ? $this->scope["brand"]:null), true), 'html', null);?></option>
								<?php 
/* -- foreach end output */
	}
}?>

							</select>
						</td>
					</tr>
					<?php 
}?>

					<tr>
						<td class="formLabel">
							<label for="catalog-section-input">������</label>
						</td>
						<td>
							<select name="section" id="catalog-section-input">
								<?php 
$_fh1_data = (isset($this->scope["sections"]) ? $this->scope["sections"] : null);
if ($this->isArray($_fh1_data) === true)
{
	foreach ($_fh1_data as $this->scope['section'])
	{
/* -- foreach start output */
?>
								<option value="<?php echo $this->scope["section"]["id"];?>"<?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'section',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true) == (isset($this->scope["section"]["id"]) ? $this->scope["section"]["id"]:null)) {
?> selected="selected"<?php 
}
if (! (isset($this->scope["section"]["selectable"]) ? $this->scope["section"]["selectable"]:null)) {
?> disabled="disabled"<?php 
}?>><?php echo $this->scope["section"]["padding"];?> <?php echo Dwoo_Plugin_escape($this, (isset($this->scope["section"]["caption"]) ? $this->scope["section"]["caption"]:null), 'html', null);?></option>
								<?php 
/* -- foreach end output */
	}
}?>

							</select>
						</td>
					</tr>
					
				</table>
	
				<div class="ui-button-box">
					<br />
					<button type="submit">���������</button>
				</div>
			</fc:tab>

			<?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',    1 => '.',  ),  2 =>   array (    0 => 'settings',    1 => 'extPhotosEnabled',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',  ),), (isset($this->scope["this"]) ? $this->scope["this"]:null), true)) {
?>
			<fc:tab name="images">
				<div class="ui-button-box">
					<a class="ui-button ui-button-list-add" href="admin.php?mod=content&amp;section=<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'section',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?>&amp;id=<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?>&amp;action=photo_add">�������� ����������</a>
				</div>
				<?php if (count((isset($this->scope["photos"]) ? $this->scope["photos"] : null)) > 0) {
?>
				<table class="catalog-photo-list ui-widget ui-widget-content">
					<?php 
$_fh2_data = (isset($this->scope["photos"]) ? $this->scope["photos"] : null);
if ($this->isArray($_fh2_data) === true)
{
	foreach ($_fh2_data as $this->scope['photo'])
	{
/* -- foreach start output */
?>
					<tr class="photo-list-item">
						<td class="controls">
							<a href="<?php echo sprintf((isset($this->scope["urlEdit"]) ? $this->scope["urlEdit"] : null), $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["photo"]) ? $this->scope["photo"]:null), true));?>" title="��������">
								<img src="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'root',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["Eresus"], false);
echo $this->scope["theme"]->getIcon('item-edit.png');?>" alt="[��������]" />
							</a>
							<a href="<?php echo sprintf((isset($this->scope["urlUp"]) ? $this->scope["urlUp"] : null), $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["photo"]) ? $this->scope["photo"]:null), true));?>" title="�������">
								<img src="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'root',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["Eresus"], false);
echo $this->scope["theme"]->getIcon('move-up.png');?>" alt="[�������]" />
							</a>
							<a href="<?php echo sprintf((isset($this->scope["urlDown"]) ? $this->scope["urlDown"] : null), $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["photo"]) ? $this->scope["photo"]:null), true));?>" title="��������">
								<img src="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'root',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["Eresus"], false);
echo $this->scope["theme"]->getIcon('move-down.png');?>" alt="[��������]" />
							</a>
							&nbsp;
							<a href="<?php echo sprintf((isset($this->scope["urlDelete"]) ? $this->scope["urlDelete"] : null), $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["photo"]) ? $this->scope["photo"]:null), true));?>" title="�������" class="delete">
								<img src="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'root',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["Eresus"], false);
echo $this->scope["theme"]->getIcon('item-delete.png');?>" alt="[�������]" />
							</a>
						</td>
						<td class="photo"><?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'thumbURL',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["photo"]) ? $this->scope["photo"]:null), true)) {
?><img src="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'thumbURL',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["photo"], false);?>" alt="" /><?php 
}?></td>
					</tr>
					<?php 
/* -- foreach end output */
	}
}?>

				</table>
				<?php 
}?>

			</fc:tab>
			<?php 
}?>


		</fc:tabs>

	</fc:tabwidget>
				
</form>
<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>