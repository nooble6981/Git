<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><div class="ui-widget ui-hepler-padding ui-padding">
	<a href="<?php echo $this->scope["listURL"];?>" class="ui-button ui-button-go-previous">��������� � ������</a>
</div>
<?php echo $this->scope["form"];
 /* end template body */
return $this->buffer . ob_get_clean();
?>