<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ;
if (count((isset($this->scope["goods"]) ? $this->scope["goods"] : null)) > 0) {
?>
	<?php 
$_fh0_data = (isset($this->scope["goods"]) ? $this->scope["goods"] : null);
if ($this->isArray($_fh0_data) === true)
{
	foreach ($_fh0_data as $this->scope['good'])
	{
/* -- foreach start output */
?>
	<div class="tovar">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td style="width:210px"><a href="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'clientURL',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?>"><?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',    1 => '.',  ),  2 =>   array (    0 => 'settings',    1 => 'mainPhotoEnabled',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',  ),), (isset($this->scope["this"]) ? $this->scope["this"]:null), true)) {

if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'thumbURL',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["good"]) ? $this->scope["good"]:null), true)) {
?><img src="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'thumbURL',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?>" alt="" /><?php 
}
else {
?>��� ���������<?php 
}

}?></a></td>
          <td>
          <div>
            <h3><a href="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'clientURL',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?>" class="green"><?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?></a></h3>
            <p><?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'about',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["good"], false);?></p>
            </div>
          </td>
        </tr>
      </table>
  </div>    
    <?php 
/* -- foreach end output */
	}
}?>

    
<?php if ((isset($this->scope["pagination"]) ? $this->scope["pagination"] : null)) {

echo $this->scope["pagination"]->render();

}?>

<?php 
}
 /* end template body */
return $this->buffer . ob_get_clean();
?>