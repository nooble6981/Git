<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><!-- Experimental -->

<div  class="pagination">
<ul>
<?php 
$_fh1_data = (isset($this->scope["pagination"]) ? $this->scope["pagination"] : null);
if ($this->isArray($_fh1_data) === true)
{
	foreach ($_fh1_data as $this->scope['page'])
	{
/* -- foreach start output */
?>
		<?php if ((isset($this->scope["page"]["current"]) ? $this->scope["page"]["current"]:null)) {
?>
			<li class="active"><?php echo $this->scope["page"]["title"];?></li>
		<?php 
}
else {
?>
			<li><a href="<?php echo $this->scope["page"]["url"];?>"><?php echo $this->scope["page"]["title"];?></a></li>
		<?php 
}?>

<?php 
/* -- foreach end output */
	}
}?>

</ul>
<div class="clear"></div>
</div><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>