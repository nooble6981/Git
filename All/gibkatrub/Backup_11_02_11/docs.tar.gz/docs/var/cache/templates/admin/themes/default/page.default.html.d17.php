<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
	<title><?php echo $this->scope["siteName"];?> - <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["page"], false);?></title>
	<link rel="StyleSheet" href="<?php echo $this->scope["siteRoot"];?>/admin/themes/default/theme.css" type="text/css">
	<link rel="StyleSheet" href="<?php echo $this->scope["siteRoot"];?>/admin/themes/default/main.css" type="text/css">
	<script type="text/javascript">//<![CDATA[
		window.Eresus = {
				siteRoot: "<?php echo $this->scope["siteRoot"];?>"
		};
	//]]></script>
	<script src="<?php echo $this->scope["siteRoot"];?>/core/jquery/jquery.min.js" type="text/javascript"></script>
	<script src="<?php echo $this->scope["siteRoot"];?>/core/jquery/jquery.cookie.js" type="text/javascript"></script>
	<script src="<?php echo $this->scope["siteRoot"];?>/core/jquery/jquery-ui.min.js" type="text/javascript"></script>
	<?php echo $this->scope["head"];?>

</head>
<body>

	<div id="header" class="header ui-widget-header">
		<div class="width-limit">
			<div id="cmsLogo">
				<a href="admin.php?mod=about">
					<img src="<?php echo $this->scope["siteRoot"];?>/admin/themes/default/img/logo.png" alt="<?php echo $this->scope["cms"]["name"];?> <?php echo $this->scope["cms"]["version"];?>"
						width="150" height="30" />
				</a>
			</div>
			<h1><?php echo $this->scope["siteName"];?> &ndash; <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["page"], false);?></h1>
			CMS <?php echo $this->scope["cms"]["name"];?> <?php echo $this->scope["cms"]["version"];?>

		</div>
	</div>

	<div class="width-limit">
		<div class="nav sidebar">

			<div class="box ui-widget ui-widget-content">
				<div class="header"><?php echo $this->scope["i18n"]->getText('admContent');?></div>
				<div class="content menu menu-content">
					<ul>
						<?php echo $this->scope["sectionMenu"];?>

					</ul>
				</div>
			</div>

			<div class="box ui-widget ui-widget-content menu">
				<?php echo $this->scope["controlMenu"];?>

			</div>

			<div class="box ui-widget ui-widget-content">
				<div class="header"><?php echo $this->scope["user"]["name"];?></div>
				<div class="content user-box">
					<a href="<?php echo $this->scope["siteRoot"];?>/admin.php?mod=users&amp;id=<?php echo $this->scope["user"]["id"];?>">
						<?php echo $this->scope["i18n"]->getText('admUsersChangePassword');?>

					</a>
					<form action="<?php echo $this->scope["siteRoot"];?>/admin.php" method="post">
						<div class="ui-button-box">
							<input type="hidden" name="action" value="logout">
							<button type="submit"><?php echo $this->scope["i18n"]->getText('strExit');?></button>
						</div>
					</form>
				</div>
			</div>

		</div>

		<div id="content">
			<?php echo $this->scope["content"];?>

		</div>
	</div>

	<script src="<?php echo $this->scope["siteRoot"];?>/admin/themes/default/theme.js" type="text/javascript"></script>
	<script src="<?php echo $this->scope["siteRoot"];?>/core/functions.js" type="text/javascript"></script>
	<?php echo $this->scope["body"];?>

</body>
</html><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>