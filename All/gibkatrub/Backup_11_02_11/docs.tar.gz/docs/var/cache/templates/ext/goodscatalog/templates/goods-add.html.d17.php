<?php
/* template head */
if (function_exists('Dwoo_Plugin_escape')===false)
	$this->getLoader()->loadPlugin('escape');
/* end template head */ ob_start(); /* template body */ ?><div class="box ui-widget-content" style="min-width: 600px; float: left;">
	<div class="header">���������� ������</div>
	<div class="content">

		<form action="admin.php" method="post" enctype="multipart/form-data" id="catalogAddDialog">

			<div class="hidden">
				<input type="hidden" name="mod" value="content" />
				<input type="hidden" name="section" value="<?php echo $this->scope["section"];?>" />
				<input type="hidden" name="action" value="insert" />
			</div>

			<table width="100%">
				<colgroup>
					<col width="10%" />
					<col width="*" />
				</colgroup>
				<tr>
					<td class="formLabel">
						<label for="catalog-article-input">�������</label>
					</td>
					<td>
						<input type="text" name="article" id="catalog-article-input" maxlength="255" />
					</td>
				</tr>
				<tr>
					<td class="formLabel">
						<label for="catalog-title-input">��������</label>
					</td>
					<td>
						<input type="text" name="title" id="catalog-title-input" maxlength="255" class="full-width" />
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<label for="catalog-about-input">������� ��������</label><br />
						<textarea name="about" id="catalog-about-input" cols="40" rows="5" class="full-width"></textarea>
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<label for="wyswyg_description">��������</label><br />
						<textarea name="wyswyg_description" id="wyswyg_description" cols="40" rows="8" class="tinymce_default wysiwyg full-width"></textarea>
					</td>
				</tr>
				<tr>
					<td class="formLabel">
						<label for="catalog-cost-input">����</label>
					</td>
					<td>
						<input type="text" name="cost" id="catalog-cost-input" maxlength="20" size="5" class="number" />
					</td>
				</tr>
				<?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',    1 => '.',  ),  2 =>   array (    0 => 'settings',    1 => 'mainPhotoEnabled',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',  ),), (isset($this->scope["this"]) ? $this->scope["this"]:null), true)) {
?>
				<tr>
					<td class="formLabel">
						<label for="catalog-photo-input">�������� ����������</label>
					</td>
					<td>
						<input type="file" name="photo" id="catalog-photo-input" />
						<div class="ui-minor">������ JPEG, PNG ��� GIF. ������ ����� �� ����� <?php echo ini_get('upload_max_filesize');?></div>
					</td>
				</tr>
				<?php 
}?>

				<tr>
					<td></td>
					<td>
						<label for="catalog-active-input">
							<input type="checkbox" name="active" value="1" id="catalog-active-input" checked="checked" />
							���������� ����� �����������
						</label>
					</td>
				</tr>
				<?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',    1 => '.',  ),  2 =>   array (    0 => 'settings',    1 => 'specialsEnabled',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',  ),), (isset($this->scope["this"]) ? $this->scope["this"]:null), true)) {
?>
				<tr>
					<td></td>
					<td>
						<label for="catalog-special-input">
							<input type="checkbox" name="special" value="1" id="catalog-special-input" />
							���� ����� &mdash; ���������������
						</label>
					</td>
				</tr>
				<?php 
}?>

				<?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',    1 => '.',  ),  2 =>   array (    0 => 'settings',    1 => 'brandsEnabled',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',  ),), (isset($this->scope["this"]) ? $this->scope["this"]:null), true)) {
?>
				<tr>
					<td class="formLabel">
						<label for="catalog-brand-input">�����</label>
					</td>
					<td>
						<select name="brand" id="catalog-brand-input">
							<option value="">(�� ��������� �� � ������ ������)</option>
							<?php 
$_fh0_data = (isset($this->scope["brands"]) ? $this->scope["brands"] : null);
if ($this->isArray($_fh0_data) === true)
{
	foreach ($_fh0_data as $this->scope['brand'])
	{
/* -- foreach start output */
?>
							<option value="<?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["brand"], false);?>"><?php echo Dwoo_Plugin_escape($this, $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["brand"]) ? $this->scope["brand"]:null), true), 'html', null);?></option>
							<?php 
/* -- foreach end output */
	}
}?>

						</select>
					</td>
				</tr>
				<?php 
}?>

				
			</table>

			<div class="ui-button-box">
				<br />
				<button type="submit">��������</button>
				<button type="button" class="cancel" onclick="history.back();">��������</button>
			</div>
			
		</form>
	</div>
</div>
<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>